/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.trabajador;

/**
 *
 * @author jbala
 */

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PublicKey;
import java.util.Base64;
import java.util.Random;

import javax.crypto.Cipher;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

public class Trabajador {
    private JTextField nombreCompletoField;
    private JTextField documentoIdentidadField;
    private JTextField correoField;
    private JTextField telefonoField;
    private JTextField codeField;
    private JTextArea infoArea;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Trabajador trabajador = new Trabajador();
            trabajador.createAndShowGUI();
        });
    }

    public void createAndShowGUI() {
        JFrame frame = new JFrame("Sistema de Trabajador");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new GridLayout(0, 2));

        frame.add(new JLabel("Nombre completo del trabajador:"));
        nombreCompletoField = new JTextField();
        frame.add(nombreCompletoField);

        frame.add(new JLabel("Documento de identidad:"));
        documentoIdentidadField = new JTextField();
        frame.add(documentoIdentidadField);

        frame.add(new JLabel("Correo electronico:"));
        correoField = new JTextField();
        frame.add(correoField);

        frame.add(new JLabel("Numero de telefono:"));
        telefonoField = new JTextField();
        frame.add(telefonoField);

        frame.add(new JLabel("Codigo de acceso:"));
        codeField = new JTextField();
        frame.add(codeField).setEnabled(false);

        JButton encryptButton = new JButton("Encriptar y Generar Codigo");
        frame.add(encryptButton);

        encryptButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nombreCompleto = nombreCompletoField.getText();
                String documentoIdentidad = documentoIdentidadField.getText();
                String correo = correoField.getText();
                String telefono = telefonoField.getText();

                // ENCRIPTAR LOS DATOS CON EL ALGORITMO RSA (usando un cifrado asimetrico)
                String datos = nombreCompleto + ";" + documentoIdentidad + ";" + correo + ";" + telefono;
                try {
                    KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
                    keyPairGenerator.initialize(2048);
                    KeyPair keyPair = keyPairGenerator.generateKeyPair();
                    PublicKey publicKey = keyPair.getPublic();
                    String encryptedData = RSAUtil.encrypt(datos, publicKey);

                    // MOSTRAR EL CODIGO GENERADO
                    String code = generateEightDigitCode();
                    codeField.setText(code);

                    // Simular el almacenamiento del codigo y los datos como si fuera en una base de
                    // datos
                    String storedCode = code;
                    String storedEncryptedData = encryptedData;

                    infoArea.setText("Datos encriptados y guardados con exito.");
                } catch (Exception ex) {
                    infoArea.setText("Error al encriptar y guardar los datos.");
                }

                nombreCompletoField.setEnabled(false);
                documentoIdentidadField.setEnabled(false);
                correoField.setEnabled(false);
                telefonoField.setEnabled(false);
                encryptButton.setEnabled(false);
                codeField.setEnabled(false);

            }
        });

        infoArea = new JTextArea();
        infoArea.setEditable(false);
        frame.add(infoArea);

        frame.pack();
        frame.setVisible(true);

    }

    private static String generateEightDigitCode() {
        Random random = new Random();
        int code = random.nextInt(90000000) + 10000000; // Rango de 10000000 a 99999999
        return String.valueOf(code);
    }
}

class RSAUtil {
    public static String encrypt(String data, PublicKey publicKey) throws Exception {
        Cipher cipher = Cipher.getInstance("RSA");
        cipher.init(Cipher.ENCRYPT_MODE, publicKey);
        byte[] encryptedBytes = cipher.doFinal(data.getBytes());
        return Base64.getEncoder().encodeToString(encryptedBytes);
    }
}